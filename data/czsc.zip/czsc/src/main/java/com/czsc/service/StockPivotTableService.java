package com.czsc.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.czsc.entity.StockPivotTable;

public interface StockPivotTableService extends IService<StockPivotTable> {
}
